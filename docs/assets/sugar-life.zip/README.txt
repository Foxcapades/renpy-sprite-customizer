The Sugary Life asset pack (from https://butterymilk.itch.io/sugary-life) is
used in accordance with the declared license:

> You are free to use sprites made with the pack in any of your commercial or
> non-commercial projects as well as edit the sprites and add something new!
>
> You can't resell the sprites, even if changes were made. You cannot use it in
> any projects related to NFT.

Please check out the artist and consider buying the full asset pack!